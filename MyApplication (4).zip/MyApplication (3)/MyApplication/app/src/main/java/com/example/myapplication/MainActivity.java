package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    //Declearing variables
    EditText FirstTex;
    TextView FirstNum;
    TextView SecondNum;
    TextView ThirdNum;
    TextView SecondTex;
    TextView ThirdTex;
    TextView FourTex;
    ImageButton ib1;
    ImageButton ib2;
    ImageButton ib3;
    Integer SpinnerSelection; // Used to know which spinner is selected


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Declearing variables using wigdets
        FirstTex = findViewById(R.id.FirstTex);
        FirstNum = findViewById(R.id.FirstNum);
        SecondNum = findViewById(R.id.SecNum);
        ThirdNum = findViewById(R.id.ThirdNum);
        SecondTex = findViewById(R.id.SecTex);
        ThirdTex = findViewById(R.id.ThirdTex);
        FourTex = findViewById(R.id.FourTex);
        ib1 = findViewById(R.id.Image1);
        ib2 = findViewById(R.id.Image2);
        ib3 = findViewById(R.id.Image3);

        //Spinner is being created


        Spinner spinner = findViewById(R.id.spinner);
        // creating options in the filler form string array
        //ArrayAdapter<CharSequence> adapter= ArrayAdapter.createFromResource(this, R.array., android.R.layout.simple_spinner_item);
        //adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //spinner.setAdapter(adapter);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.units_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        //listening for the events selected
        spinner.setOnItemSelectedListener(this);




    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String option = parent.getItemAtPosition(position).toString();

        //Take action based on the item selected
        if (option.toString().equals("Meters")){
            SelectMeters(parent);
        }

        if (option.toString().equals("Celcius")){
            SelectCelsius(parent);
        }

        if (option.toString().equals("Kilogram")){
            SelectKilograms(parent);
        }




    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void SelectMeters (AdapterView<?> parent)
    {
        SpinnerSelection = 1;

        FirstNum.setText("");
        SecondNum.setText("");
        ThirdNum.setText("");
        SecondTex.setText("Centimetre");
        ThirdTex.setText("Foot");
        FourTex.setText("Inch");


    }

    public void SelectCelsius (AdapterView<?> parent)
    {
        SpinnerSelection = 2;

        FirstNum.setText("");
        SecondNum.setText("");
        ThirdNum.setText("");
        SecondTex.setText("Farhenheit");
        ThirdTex.setText("Kelvin");
        FourTex.setText("");


    }

    public void  SelectKilograms (AdapterView<?> parent)
    {
        SpinnerSelection = 3;

        FirstNum.setText("");
        SecondNum.setText("");
        ThirdNum.setText("");
        SecondTex.setText("Grams");
        ThirdTex.setText("Ounce");
        FourTex.setText("Pounds");


    }


    public void ConvertMetres(View view){
        //Checking for errors
        if (SpinnerSelection !=1){
            Toast.makeText(this,"please select the correct conversion image",Toast.LENGTH_SHORT).show();
            return;

        }

        double inputValue;
        try
            {
             String stringInput = FirstTex.getText().toString();
             inputValue=Double.parseDouble(stringInput);
            }
        catch (Exception e){
            Toast.makeText(this, "please enter a valid value", Toast.LENGTH_SHORT).show();
            return;

        }

        double First = (inputValue *100); // m to cm
        double second = (inputValue* 3.28084);// m to feet
        double third = (inputValue*39.3701); // m to inch

        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        FirstNum.setText(decimalFormat.format(First));
        SecondNum.setText(decimalFormat.format(second));
        ThirdNum.setText(decimalFormat.format(third));
    }
    public void ConvertCelcius(View view){
        //Checking for errors
        if (SpinnerSelection !=2){
            Toast.makeText(this,"please select the correct conversion image",Toast.LENGTH_SHORT).show();
            return;

        }

        double inputValue;
        try
        {
            String stringInput = FirstTex.getText().toString();
            inputValue=Double.parseDouble(stringInput);
        }
        catch (Exception e){

            Toast.makeText(this, "please enter a valid value", Toast.LENGTH_SHORT).show();
            return;

        }

        double First = (inputValue *(9/5 + 32)); // Celcius to Farhenheits
        double second = (inputValue + 273.15);// Celcius to Kelvin


        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        FirstNum.setText(decimalFormat.format(First));
        SecondNum.setText(decimalFormat.format(second));

    }

    public void ConvertKilogram(View view){
        //Checking for errors
        if (SpinnerSelection !=3){
            Toast.makeText(this,"please select the correct conversion image",Toast.LENGTH_SHORT).show();
            return;

        }

        double inputValue;
        try
        {
            String stringInput = FirstTex.getText().toString();
            inputValue=Double.parseDouble(stringInput);
        }
        catch (Exception e){

            Toast.makeText(this, "please enter a valid value", Toast.LENGTH_SHORT).show();
            return;

        }

        double First = (inputValue *1000); // kg to g
        double second = (inputValue* 35.274);// kg to Ounce
        double third = (inputValue*2.20462); // Kg to Pound

        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        FirstNum.setText(decimalFormat.format(First));
        SecondNum.setText(decimalFormat.format(second));
        ThirdNum.setText(decimalFormat.format(third));
    }


}